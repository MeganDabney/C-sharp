﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DabneyMeganRecentlyVisitedSites
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            System.Diagnostics.Process.Start("Chrome", "https://my.ivytech.edu/");

            linkMove('1');


        }

        private void linkLabel1_MouseHover(object sender, EventArgs e)
        {
            label1.Text = "Homepage for my school";
        }

        private void linkLabel2_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            System.Diagnostics.Process.Start("Chrome", "https://youtube.com/");
            linkMove('2');

        }

        private void linkLabel2_MouseHover(object sender, EventArgs e)
        {
            label1.Text = "Online videos";
        }

        private void linkLabel3_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            System.Diagnostics.Process.Start("Chrome", "https://www.google.com");
            linkMove('3');
        }

        private void linkLabel3_MouseHover(object sender, EventArgs e)
        {
            label1.Text = "Popular search enging";
        }
        private void linkMove(char a)

        {
            if (a == '1')
            {
                linkLabel1.Location = new System.Drawing.Point(50, 50);
                linkLabel2.Location = new System.Drawing.Point(50, 75);
                linkLabel3.Location = new System.Drawing.Point(50, 100);

            }
            else if (a == '2')
                
               
                {
                    linkLabel2.Location = new System.Drawing.Point(50, 50);
                    linkLabel3.Location = new System.Drawing.Point(50, 75);
                    linkLabel1.Location = new System.Drawing.Point(50, 100);

                }
            if (a == '3')
            {
                linkLabel3.Location = new System.Drawing.Point(50, 50);
                linkLabel1.Location = new System.Drawing.Point(50, 75);
                linkLabel2.Location = new System.Drawing.Point(50, 100);

            }

        }
    }
}



