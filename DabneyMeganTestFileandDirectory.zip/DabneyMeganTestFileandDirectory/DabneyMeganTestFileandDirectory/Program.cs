﻿using System;
using System.IO;
using static System.Console;

namespace DabneyMeganTestFileandDirectory
{
    class Program
    {
        static void Main(string[] args)
        {
            const string END = "end";
            string directoryName;
            string fileName;
            string[] listOfFiles;

            WriteLine("Enter a directory name to search: ");
            directoryName = ReadLine();
            while(directoryName != END)
            {
                if(Directory.Exists(directoryName))
                {
                    listOfFiles = Directory.GetFiles(directoryName);
                    for (int x = 0; x < listOfFiles.Length; ++x)
                    WriteLine("{0}", listOfFiles[x]);

                    WriteLine("Enter one of the filenames: ");
                    fileName = ReadLine();
                    if(File.Exists(fileName))
                    {
                        WriteLine("The file was created " + File.GetCreationTime(fileName));
                    }
                    else
                    {
                        WriteLine("The file does not exist.");
                    }

                }
                else
                {
                    WriteLine("That directory does not exist.");
                }
                WriteLine("Enter a directory name to search: ");
                directoryName = ReadLine();
            }
        }
    }
}
