﻿using System;
using static System.Console;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DabneyMeganSubscriptValidation
{
    class Program
    {
        static void Main(string[] args)
        {
            double[] array = { 2.95, 1.14, 3.25, 14.25, 8.25, 4.23, 1.18, 6.36, 7.45, 5.18, 10.00, 8.78, 9.79, 7.12, 3.33, 2.13, 5.45, 2.21, 1.19, 0.02 };

            int subscript = 0;
            string inputValue;
            while (subscript >= 0)
            {
                try
                {
                    Write("Enter a subscript value>> ");
                    inputValue = ReadLine();
                    if (!int.TryParse(inputValue, out subscript))
                    {
                        subscript = 0;
                        WriteLine("You must enter a valid number.");
                    }
                    WriteLine("The array value is {0}", array[subscript]);
                }
                catch (IndexOutOfRangeException e)
                {
                    WriteLine("ERROR: You must enter a number from 0 to 19.");
                    WriteLine(e.Message);
                }
            }

        }
    }
}


